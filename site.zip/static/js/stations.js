/* Hinterland Archive — curated open radio network (HTTPS-only edition)
 *
 * A hand-picked selection of public internet-radio streams chosen to sit
 * alongside the archive's listening sensibility: ambient, drone, calm,
 * classical, jazz, FIP, folk, world and lossless hi-fi.
 *
 * RELIABILITY POLICY — every endpoint here is:
 *   • served over HTTPS, so nothing is blocked as mixed content on the site;
 *   • a plain Icecast/HTTP-progressive stream (no HLS, no DRM, no auth);
 *   • MP3 or AAC unless explicitly tagged FLAC — those few lossless entries
 *     play on desktop Chrome / Firefox / Edge (Safari/iOS will fall back).
 * No crossOrigin is requested, so playback works regardless of CORS.
 *
 * Streams are taken directly from the broadcasters' own public endpoints:
 *   SomaFM · Radio Paradise · Radio France (FIP / France Musique) ·
 *   Jazz Radio · Mother Earth Radio · Radio Calico · OrganLive.
 *
 * `np` marks streams whose live "now playing" metadata can be polled
 * (currently Radio Paradise's public API).
 */

window.HINTERLAND_SOURCES = {
  soma:       { label: 'SomaFM',            url: 'https://somafm.com' },
  rp:         { label: 'Radio Paradise',    url: 'https://radioparadise.com' },
  rf:         { label: 'Radio France · FIP / France Musique', url: 'https://www.radiofrance.fr/fip' },
  jazzradio:  { label: 'Jazz Radio',        url: 'https://www.jazzradio.fr' },
  motherearth:{ label: 'Mother Earth Radio', url: 'https://www.motherearthradio.de' },
  calico:     { label: 'Radio Calico',      url: 'https://radio-calico.com' },
  organlive:  { label: 'OrganLive',         url: 'https://organlive.com' }
};

const SOMA = 'https://ice2.somafm.com/';
const RF   = 'https://icecast.radiofrance.fr/';
const RP   = 'https://stream.radioparadise.com/';

window.HINTERLAND_STATIONS = [
  {
    id: 'ambient',
    ru: 'Эмбиент и дрон',
    en: 'Ambient & drone',
    hintRu: 'Длинные дроновые и космические потоки — ближе всего по духу к полевым записям.',
    hintEn: 'Long-form drone and deep-space streams — closest in spirit to the field archive.',
    stations: [
      { name: 'Drone Zone · SomaFM',        url: SOMA + 'dronezone-128-mp3',     fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Deep Space One · SomaFM',    url: SOMA + 'deepspaceone-128-mp3',  fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Space Station Soma · SomaFM',url: SOMA + 'spacestation-128-mp3',  fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Synphaera · SomaFM',         url: SOMA + 'synphaera-128-mp3',     fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'The Dark Zone · SomaFM',     url: SOMA + 'darkzone-128-mp3',      fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Mission Control · SomaFM',   url: SOMA + 'missioncontrol-128-mp3',fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Cliqhop idm · SomaFM',       url: SOMA + 'cliqhop-128-mp3',       fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'n5MD Radio · SomaFM',        url: SOMA + 'n5md-128-mp3',          fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Vaporwaves · SomaFM',        url: SOMA + 'vaporwaves-128-mp3',    fmt: 'MP3 128', place: 'San Francisco', src: 'soma' }
    ]
  },
  {
    id: 'calm',
    ru: 'Покой и медитация',
    en: 'Calm & meditative',
    hintRu: 'Мягкие, созерцательные потоки для фонового слушания и работы.',
    hintEn: 'Soft, contemplative streams for ambient listening and focus.',
    stations: [
      { name: 'Radio Paradise · Mellow Mix', url: RP + 'mellow-320', fmt: 'AAC 320', place: 'Paradise, CA', src: 'rp', np: { p: 'rp', chan: 1 } },
      { name: 'Fluid · SomaFM',              url: SOMA + 'fluid-128-mp3',  fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'The Trip · SomaFM',           url: SOMA + 'thetrip-128-mp3', fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'France Musique · Classique Easy', url: RF + 'francemusiqueclassiqueeasy-hifi.aac', fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'Mother Earth Radio',          url: 'https://motherearth.streamserver24.com/listen/motherearth/motherearth.flac-lo', fmt: 'FLAC', place: 'Deutschland', src: 'motherearth' }
    ]
  },
  {
    id: 'classical',
    ru: 'Классика и хоралы',
    en: 'Classical & choral',
    hintRu: 'Созерцательная классика, барокко, орган и современная академическая музыка.',
    hintEn: 'Contemplative classical, baroque, organ and contemporary concert music.',
    stations: [
      { name: 'France Musique',                 url: RF + 'francemusique-hifi.aac',                  fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'France Musique · Classique Plus', url: RF + 'francemusiqueclassiqueplus-hifi.aac',    fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'France Musique · Baroque',       url: RF + 'francemusiquebaroque-hifi.aac',           fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'France Musique · Concerts',      url: RF + 'francemusiqueconcertsradiofrance-hifi.aac', fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'France Musique · La Contemporaine', url: RF + 'francemusiquelacontemporaine-hifi.aac', fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'France Musique · Ocora Monde',   url: RF + 'francemusiqueocoramonde-hifi.aac',         fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'OrganLive',                      url: 'https://play.organlive.com:7010/320',          fmt: 'MP3 320', place: 'USA', src: 'organlive' }
    ]
  },
  {
    id: 'jazz',
    ru: 'Джаз и лаунж',
    en: 'Jazz & lounge',
    hintRu: 'Поздневечерний джаз, босанова и лаунж.',
    hintEn: 'Late-night jazz, bossa nova and lounge.',
    stations: [
      { name: 'FIP Jazz',                   url: RF + 'fipjazz-hifi.aac',          fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'France Musique · La Jazz',   url: RF + 'francemusiquelajazz-hifi.aac', fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'Jazz Radio Nationale',       url: 'https://jazzradio.ice.infomaniak.ch/frequencejazz-high.mp3', fmt: 'MP3', place: 'France', src: 'jazzradio' },
      { name: 'Jazz Radio',                 url: 'https://jazzradio.ice.infomaniak.ch/jazzradio-high.mp3',     fmt: 'MP3', place: 'France', src: 'jazzradio' },
      { name: 'The In-Sound · SomaFM',      url: SOMA + 'insound-128-mp3',         fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Bossa Beyond · SomaFM',      url: SOMA + 'bossa-128-mp3',           fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Sonic Universe · SomaFM',    url: SOMA + 'sonicuniverse-128-mp3',   fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Secret Agent · SomaFM',      url: SOMA + 'secretagent-128-mp3',     fmt: 'MP3 128', place: 'San Francisco', src: 'soma' }
    ]
  },
  {
    id: 'fip',
    ru: 'FIP и его оттенки',
    en: 'FIP & its colours',
    hintRu: 'Легендарный французский FIP и его тематические каналы.',
    hintEn: 'The legendary French FIP and its themed sister channels.',
    stations: [
      { name: 'FIP',              url: RF + 'fip-hifi.aac',          fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'FIP Rock',         url: RF + 'fiprock-hifi.aac',      fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'FIP Groove',       url: RF + 'fipgroove-hifi.aac',    fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'FIP Pop',          url: RF + 'fippop-hifi.aac',       fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'FIP Electro',      url: RF + 'fipelectro-hifi.aac',   fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'FIP Nouveautés',   url: RF + 'fipnouveautes-hifi.aac',fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'FIP Metal',        url: RF + 'fipmetal-hifi.aac',     fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'FIP Hip-Hop',      url: RF + 'fiphiphop-hifi.aac',    fmt: 'AAC', place: 'France', src: 'rf' }
    ]
  },
  {
    id: 'world',
    ru: 'Фолк и мир',
    en: 'Folk & world',
    hintRu: 'Народная музыка, кельтские мотивы, регги и звуки со всего света.',
    hintEn: 'Folk traditions, Celtic strands, reggae and sounds from around the world.',
    stations: [
      { name: 'FIP Monde',                  url: RF + 'fipworld-hifi.aac',   fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'FIP Reggae',                 url: RF + 'fipreggae-hifi.aac',  fmt: 'AAC', place: 'France', src: 'rf' },
      { name: 'Folk Forward · SomaFM',      url: SOMA + 'folkfwd-128-mp3',   fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'ThistleRadio · SomaFM',      url: SOMA + 'thistle-128-mp3',   fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Boot Liquor · SomaFM',       url: SOMA + 'bootliquor-128-mp3',fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Suburbs of Goa · SomaFM',    url: SOMA + 'suburbsofgoa-128-mp3', fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Heavyweight Reggae · SomaFM',url: SOMA + 'reggae-128-mp3',    fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Radio Paradise · World Mix', url: RP + 'global-320',          fmt: 'AAC 320', place: 'Paradise, CA', src: 'rp', np: { p: 'rp', chan: 3 } }
    ]
  },
  {
    id: 'eclectic',
    ru: 'Грув, инди и ретро',
    en: 'Groove, indie & retro',
    hintRu: 'Эклектичные подборки, инди-поп и ретро-волны.',
    hintEn: 'Eclectic blends, indie-pop and retro waves.',
    stations: [
      { name: 'Radio Paradise · Main Mix',  url: RP + 'aac-320',             fmt: 'AAC 320', place: 'Paradise, CA', src: 'rp', np: { p: 'rp', chan: 0 } },
      { name: 'Radio Paradise · Rock Mix',  url: RP + 'rock-320',            fmt: 'AAC 320', place: 'Paradise, CA', src: 'rp', np: { p: 'rp', chan: 2 } },
      { name: 'Groove Salad · SomaFM',      url: SOMA + 'groovesalad-128-mp3', fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Groove Salad Classic · SomaFM', url: SOMA + 'gsclassic-128-mp3', fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Lush · SomaFM',              url: SOMA + 'lush-128-mp3',      fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Beat Blender · SomaFM',      url: SOMA + 'beatblender-128-mp3', fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Indie Pop Rocks! · SomaFM',  url: SOMA + 'indiepop-128-mp3',  fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Underground 80s · SomaFM',   url: SOMA + 'u80s-128-mp3',      fmt: 'MP3 128', place: 'San Francisco', src: 'soma' },
      { name: 'Left Coast 70s · SomaFM',    url: SOMA + 'seventies-128-mp3', fmt: 'MP3 128', place: 'San Francisco', src: 'soma' }
    ]
  },
  {
    id: 'lossless',
    ru: 'Lossless и хай-фай',
    en: 'Lossless & hi-fi',
    hintRu: 'Потоки без потерь (FLAC) — в тон lossless-каталогу архива. Лучше всего играют в Chrome, Firefox и Edge на десктопе.',
    hintEn: 'Lossless (FLAC) streams in keeping with the archive’s lossless catalogue. Best on desktop Chrome, Firefox and Edge.',
    stations: [
      { name: 'Radio Paradise · Main (FLAC)',   url: RP + 'flac',        fmt: 'FLAC', place: 'Paradise, CA', src: 'rp', np: { p: 'rp', chan: 0 } },
      { name: 'Radio Paradise · Mellow (FLAC)', url: RP + 'mellow-flac', fmt: 'FLAC', place: 'Paradise, CA', src: 'rp', np: { p: 'rp', chan: 1 } },
      { name: 'Radio Paradise · Rock (FLAC)',   url: RP + 'rock-flac',   fmt: 'FLAC', place: 'Paradise, CA', src: 'rp', np: { p: 'rp', chan: 2 } },
      { name: 'Mother Earth Radio (FLAC)',      url: 'https://motherearth.streamserver24.com/listen/motherearth/motherearth.flac-lo', fmt: 'FLAC', place: 'Deutschland', src: 'motherearth' },
      { name: 'Radio Calico (FLAC)',            url: 'https://stream.radio-calico.com/calico', fmt: 'FLAC', place: 'USA', src: 'calico' }
    ]
  }
];
