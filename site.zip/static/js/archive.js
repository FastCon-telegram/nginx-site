/* Hinterland Archive — catalogue browser
 *
 * Renders, filters, sorts and paginates the structured dataset from
 * archive-data.js. Filtering is field-typed (region id, ISO year,
 * duration bucket in seconds, full-text on title/contributor/cat no.),
 * sorting offers newest / oldest / longest / shortest / most-played, and
 * pagination grows the visible slice. Language follows <html lang>.
 */

(function () {
  const data = window.HINTERLAND_ARCHIVE || [];
  const regions = window.HINTERLAND_REGIONS || [];
  const lang = (document.documentElement.lang || 'ru').slice(0, 2);
  const list = document.getElementById('rec-list');
  if (!list || !data.length) return;

  const elRegion = document.getElementById('f-region');
  const elYear   = document.getElementById('f-year');
  const elDur    = document.getElementById('f-dur');
  const elQ      = document.getElementById('f-q');
  const elSort   = document.getElementById('f-sort');
  const elCount  = document.getElementById('rec-count');
  const elMore   = document.getElementById('load-more');
  const elPage   = document.getElementById('page-info');

  const PAGE = 24;
  let page = 1;

  const L = lang === 'ru' ? {
    locale: 'ru-RU',
    showing: (n, t) => 'Показано ' + n.toLocaleString('ru-RU') + ' из ' + t.toLocaleString('ru-RU') + ' позиций открытого индекса',
    sortedBy: ' · сортировка: ',
    pageOf: (p, t) => 'Страница ' + p + ' из ' + t,
    more: 'Загрузить ещё 24',
    allShown: 'Показаны все позиции выдачи',
    none: 'Ничего не найдено — измените фильтры или поиск.',
    plays: 'прослушиваний', GB: 'ГБ', MB: 'МБ',
    sorts: { new: 'новые сверху', old: 'старые сверху', long: 'самые длинные', short: 'самые короткие', plays: 'по прослушиваниям' }
  } : {
    locale: 'en-US',
    showing: (n, t) => 'Showing ' + n.toLocaleString('en-US') + ' of ' + t.toLocaleString('en-US') + ' open-index entries',
    sortedBy: ' · sorted: ',
    pageOf: (p, t) => 'Page ' + p + ' of ' + t,
    more: 'Load 24 more',
    allShown: 'All entries shown',
    none: 'Nothing matches — adjust the filters or search.',
    plays: 'plays', GB: 'GB', MB: 'MB',
    sorts: { new: 'newest first', old: 'oldest first', long: 'longest', short: 'shortest', plays: 'most played' }
  };

  function pad(n) { return String(n).padStart(4, '0'); }
  function regionLabel(id) { const r = regions.find(x => x.id === id); return r ? r[lang] : id; }

  function fmtDur(s) {
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    return h > 0
      ? h + ':' + String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0')
      : m + ':' + String(sec).padStart(2, '0');
  }
  function fmtDate(iso) {
    if (lang === 'ru') { const p = iso.split('-'); return p[2] + '.' + p[1] + '.' + p[0]; }
    return iso;
  }
  function fmtSize(mb) {
    return mb >= 1024 ? (mb / 1024).toFixed(1).replace('.', lang === 'ru' ? ',' : '.') + ' ' + L.GB
                      : mb + ' ' + L.MB;
  }
  function durBucket(s) {
    if (s < 600) return 'u10';
    if (s < 3600) return '10-60';
    if (s <= 14400) return '1-4';
    return '4+';
  }
  function esc(str) {
    return String(str).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }

  // Build region + year options from the data.
  function buildOptions() {
    if (elRegion) {
      regions.forEach(r => {
        const o = document.createElement('option');
        o.value = r.id; o.textContent = r[lang];
        elRegion.appendChild(o);
      });
    }
    if (elYear) {
      const years = Array.from(new Set(data.map(r => r.dateISO.slice(0, 4)))).sort().reverse();
      years.forEach(y => { const o = document.createElement('option'); o.value = y; o.textContent = y; elYear.appendChild(o); });
    }
  }

  function read() {
    return {
      region: elRegion ? elRegion.value : '',
      year:   elYear ? elYear.value : '',
      dur:    elDur ? elDur.value : '',
      q:      elQ ? elQ.value.trim().toLowerCase() : '',
      sort:   elSort ? elSort.value : 'new'
    };
  }

  function comparator(sort) {
    switch (sort) {
      case 'old':   return (a, b) => a.no - b.no;
      case 'long':  return (a, b) => b.durSec - a.durSec;
      case 'short': return (a, b) => a.durSec - b.durSec;
      case 'plays': return (a, b) => b.plays - a.plays;
      default:      return (a, b) => b.no - a.no;
    }
  }

  function filtered(f) {
    return data.filter(r => {
      if (f.region && r.regionId !== f.region) return false;
      if (f.year && r.dateISO.slice(0, 4) !== f.year) return false;
      if (f.dur && durBucket(r.durSec) !== f.dur) return false;
      if (f.q) {
        const hay = (pad(r.no) + ' ' + r[lang].title + ' ' + r[lang].by + ' ' + regionLabel(r.regionId)).toLowerCase();
        if (hay.indexOf(f.q) === -1) return false;
      }
      return true;
    });
  }

  function rowHtml(r) {
    const t = r[lang];
    const badge = r.tag ? ' <span class="badge">' + esc(r.tag) + '</span>' : '';
    const tip = r.plays.toLocaleString(L.locale) + ' ' + L.plays + ' · ' + fmtSize(r.sizeMB) + ' · ' + r.fmt;
    return '<li class="recording" id="hfr-' + pad(r.no) + '" title="' + esc(tip) + '">' +
      '<span class="cat-no">HFR-' + pad(r.no) + '</span>' +
      '<span class="title">' + esc(t.title) + badge + '<em>' + esc(t.by) + '</em></span>' +
      '<span class="region">' + esc(regionLabel(r.regionId)) + '</span>' +
      '<span class="date">' + fmtDate(r.dateISO) + '</span>' +
      '<span class="dur">' + fmtDur(r.durSec) + '</span>' +
      '<a href="#hfr-' + pad(r.no) + '" class="dl">' + r.fmt + ' ↓</a>' +
      '</li>';
  }

  function render() {
    const f = read();
    const rows = filtered(f).sort(comparator(f.sort));
    const total = rows.length;
    const slice = rows.slice(0, page * PAGE);

    list.innerHTML = slice.length
      ? slice.map(rowHtml).join('')
      : '<li class="no-results">' + L.none + '</li>';

    if (elCount) elCount.textContent = L.showing(slice.length, total) + L.sortedBy + L.sorts[f.sort];
    if (elPage) elPage.textContent = total ? L.pageOf(Math.min(page, Math.ceil(total / PAGE)), Math.max(1, Math.ceil(total / PAGE))) : '';
    if (elMore) {
      const done = slice.length >= total;
      elMore.disabled = done;
      elMore.style.opacity = done ? '0.4' : '';
      elMore.style.cursor = done ? 'default' : 'pointer';
      elMore.textContent = done ? L.allShown : L.more;
    }
  }

  function resetAndRender() { page = 1; render(); }

  buildOptions();
  [elRegion, elYear, elDur, elSort].forEach(el => { if (el) el.addEventListener('change', resetAndRender); });
  if (elQ) elQ.addEventListener('input', resetAndRender);
  if (elMore) elMore.addEventListener('click', () => { page++; render(); });

  render();
})();
