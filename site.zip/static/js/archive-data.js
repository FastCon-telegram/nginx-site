/* Hinterland Archive — catalogue data layer
 *
 * A real, structured, bilingual dataset that powers the archive page:
 * field-typed records (duration in seconds, ISO dates, region ids, play
 * counts, sizes) so that filtering and sorting operate on data rather than
 * on rendered text. The first 24 positions are hand-authored; the rest of
 * the open index (down to HFR-0001) is generated deterministically from a
 * seeded function, so the catalogue is identical on every load and across
 * both languages.
 */

window.HINTERLAND_REGIONS = [
  { id: 'neurope',  ru: 'Северная Европа',   en: 'Northern Europe' },
  { id: 'boreal',   ru: 'Бореальный лес',    en: 'Boreal forest' },
  { id: 'atlantic', ru: 'Северная Атлантика', en: 'North Atlantic' },
  { id: 'pacific',  ru: 'Тихий океан',       en: 'Pacific' },
  { id: 'casia',    ru: 'Центральная Азия',  en: 'Central Asia' },
  { id: 'samerica', ru: 'Южная Америка',     en: 'South America' },
  { id: 'british',  ru: 'Британские острова', en: 'British Isles' },
  { id: 'vlf',      ru: 'Атмосфера / VLF',   en: 'Atmospheric / VLF' },
  { id: 'subter',   ru: 'Подземное',         en: 'Subterranean' }
];

(function () {
  // Deterministic play count + size from catalogue number.
  function playsFor(no) { return 900 + ((no * 2654435761) >>> 0) % 41000; }
  function sizeMBFor(durSec) { return Math.round(durSec / 60 * 34); } // ~34 MB/min FLAC

  function rec(no, dateISO, durSec, regionId, fmt, ru, en, tag) {
    return {
      no: no, dateISO: dateISO, durSec: durSec, regionId: regionId,
      fmt: fmt, tag: tag || '', plays: playsFor(no), sizeMB: sizeMBFor(durSec),
      ru: { title: ru[0], by: ru[1] },
      en: { title: en[0], by: en[1] }
    };
  }

  const seed = [
    rec(418, '2026-04-22', 7457,  'atlantic', 'FLAC', ['Голос ледника, поздняя оттепель','Тоура Хельгадоттир · Ватнайёкюдль, IS'], ['Glacier voice, late thaw','Þóra Helgadóttir · Vatnajökull, IS'], 'binaural'),
    rec(417, '2026-04-19', 2588,  'boreal',   'FLAC', ['Утренний хор, неделя 18','П. Вайнио · Водлозерский, РФ'], ['Dawn chorus, week 18','P. Vainio · Vodlozersky, RU']),
    rec(416, '2026-04-14', 144000,'pacific',  'FLAC', ['Падение кита, 30 км севернее','MBARI по разрешению · Тихий океан'], ['Whale-fall, 30 km north','MBARI under permit · Pacific deep'], 'гидрофон'),
    rec(415, '2026-04-08', 6150,  'casia',    'FLAC', ['Базар на закрытии, три ракурса','А. Раззаков · Ташкент, UZ'], ['Bazaar at closing, three perspectives','A. Razzakov · Tashkent, UZ']),
    rec(414, '2026-04-01', 22724, 'vlf',      'FLAC', ['Солнечный ветер, августовский перигелий','Д. Ортис · Патагония, AR'], ['Solar wind, August perihelion','D. Ortiz · Patagonia, AR'], 'VLF'),
    rec(413, '2026-03-25', 1682,  'atlantic', 'FLAC', ['Фумарола, медленно остывающая','С. Йонсдоттир · Рейкьянес, IS'], ['Fumarole, slowly cooling','S. Jónsdóttir · Reykjanes, IS']),
    rec(412, '2026-03-21', 4135,  'british',  'FLAC', ['Гэльская псалмодия, полная вечерняя служба','Записи из Сторновея · Внешние Гебриды, GB'], ['Gaelic psalmody, full evening service','The Stornoway recordings · Outer Hebrides, GB']),
    rec(411, '2026-03-14', 27900, 'british',  'FLAC', ['Ткацкий цех Мейсикойд, полная смена','Э. Дэвис · Понтипридд, GB'], ['Loom shed at Maesycoed, full shift','E. Davies · Pontypridd, GB']),
    rec(410, '2026-03-08', 4462,  'subter',   'FLAC', ['Подземная река, весеннее половодье','М. Ковач · Аггтелек, HU'], ['Cave river, spring high-water','M. Kovács · Aggtelek, HU']),
    rec(409, '2026-03-02', 43680, 'neurope',  'FLAC', ['Отступление паковых льдов, три ночи','К. Эриксен · Шпицберген, NO'], ['Pack ice retreat, three nights','K. Eriksen · Svalbard, NO']),
    rec(408, '2026-02-23', 2469,  'british',  'FLAC', ['Один колокол, шесть деревень, одно воскресенье','Р. Чен · Сноудония, GB'], ['Single bell, six villages, one Sunday','R. Chen · Snowdonia, GB']),
    rec(407, '2026-02-18', 3734,  'boreal',   'FLAC', ['Ледоход реки, 21 день сжато','В. Соколов · Карелия, РФ'], ['A river breaking up, 21 days compressed','V. Sokolov · Karelia, RU']),
    rec(406, '2026-02-11', 2330,  'atlantic', 'FLAC', ['Гейзерный бассейн, четыре камеры','С. Йонсдоттир · Хверавеллир, IS'], ['Geothermal pool, four chambers','S. Jónsdóttir · Hveravellir, IS'], '4 канала'),
    rec(405, '2026-02-05', 1338,  'neurope',  'FLAC', ['Собор в три часа дня','Л. Петрович · Суботица, RS'], ["Cathedral at three o'clock",'L. Petrović · Subotica, RS']),
    rec(404, '2026-01-29', 6480,  'neurope',  'FLAC', ['Литейный цех, горячая разливка','Й. Сандстрём · Карлскуга, SE'], ['Foundry, hot pour','J. Sandström · Karlskoga, SE']),
    rec(403, '2026-01-22', 11648, 'casia',    'FLAC', ['Полуденная степь, четыре анемометра','Б. Хусаинов · Актобе, KZ'], ['Steppe at noon, four anemometers','B. Khusainov · Aktobe, KZ']),
    rec(402, '2026-01-15', 2301,  'neurope',  'FLAC', ['Гранитный карьер, утренний пересменок','Ф. Лима · Вила-Реал, PT'], ['Granite quarry, dawn shift change','F. Lima · Vila Real, PT']),
    rec(401, '2026-01-10', 51660, 'atlantic', 'FLAC', ['Приливная мельница, полный лунный цикл','О. Ле Бра · Брэа, FR'], ['Tidal mill, full lunar cycle','O. Le Bras · Bréhat, FR']),
    rec(400, '2026-01-01', 14400, 'vlf',      'FLAC', ['Четыреста · юбилейный микс','Редакция · разные локации'], ['Four hundred · an anniversary mix','The editors · various'], 'юбилей'),
    rec(399, '2025-12-28', 8310,  'vlf',      'FLAC', ['Шипение полярного сияния, январь','Д. Ортис · Патагония, AR'], ['Aurora hiss, January','D. Ortiz · Patagonia, AR']),
    rec(398, '2025-12-19', 1448,  'pacific',  'FLAC', ['Крыланы, вечерний вылет','Н. Перейра · Керала, IN'], ['Megachiroptera, evening fly-out','N. Pereira · Kerala, IN']),
    rec(397, '2025-12-12', 3120,  'boreal',   'FLAC', ['Болото в полночь, четыре канала','П. Вайнио · Патвинсуо, FI'], ['Bog at midnight, four channels','P. Vainio · Patvinsuo, FI'], '4 канала'),
    rec(396, '2025-12-05', 17298, 'neurope',  'FLAC', ['Паромная переправа, четыре зимних рейса','Х. Линдквист · Кваркен, FI'], ['Ferry crossing, four winter trips','H. Lindqvist · Kvarken, FI']),
    rec(395, '2025-11-28', 5922,  'samerica', 'FLAC', ['Солончак, сухой месяц','М. Санчес · Салар-де-Уюни, BO'], ['Salt pan, dry month','M. Sánchez · Salar de Uyuni, BO'])
  ];

  // --- procedural fill for the rest of the open index (394 → 1) ---
  const titlesRu = ['Туман над фьордом','Ночной перегон оленей','Капель в карстовой пещере','Прибой на галечном пляже','Колокола на рассвете','Ветер в антеннах','Ледяная корка, первое утро','Грозовой фронт, четыре микрофона','Перелёт гусей, сумерки','Метель у маяка','Тёплый дождь в ельнике','Сухая гроза над плато','Шорох тростника','Гул моста под нагрузкой','Утренний рынок, дальний план','Орган в пустом соборе','Талая вода, апрель','Цикады, полуденный пик','Паромный гудок в тумане','Печь стеклодува, ночная смена','Колодец, эхо ведра','Степной зной, анемометры','Прилив в устье реки','Снег на проводах','Гончарный круг, полная сессия'];
  const titlesEn = ['Mist over the fjord','Night reindeer drive','Dripwater in a karst cave','Surf on a shingle beach','Bells at first light','Wind through the antennas','Ice crust, first morning','Storm front, four microphones','Geese on passage, dusk','Blizzard by the lighthouse','Warm rain in spruce','Dry storm over the plateau','Rustle of reeds','Bridge humming under load','Morning market, distant field','Organ in an empty cathedral','Meltwater, April','Cicadas at midday peak','Ferry horn in fog','Glass furnace, night shift','A well, the echo of the bucket','Steppe heat, anemometers','Tide in the river mouth','Snow on the wires',"Potter's wheel, full session"];
  const varRu = ['', '', ', три ракурса', ', зимняя версия', ', полная сессия', ', ночная редакция'];
  const varEn = ['', '', ', three perspectives', ', winter version', ', full session', ', night edit'];
  const engRu = ['Тоура Хельгадоттир','П. Вайнио','В. Соколов','Х. Линдквист','Д. Ортис','А. Раззаков','С. Йонсдоттир','Э. Дэвис','Р. Чен','Н. Перейра','М. Ковач','К. Эриксен','Б. Хусаинов','О. Ле Бра'];
  const engEn = ['Þóra Helgadóttir','P. Vainio','V. Sokolov','H. Lindqvist','D. Ortiz','A. Razzakov','S. Jónsdóttir','E. Davies','R. Chen','N. Pereira','M. Kovács','K. Eriksen','B. Khusainov','O. Le Bras'];
  const cc = ['IS','FI','RU','SE','AR','UZ','IS','GB','GB','IN','HU','NO','KZ','FR'];
  const regOrder = ['neurope','boreal','atlantic','pacific','casia','samerica','british','vlf','subter'];
  const placeRu = { neurope:'Кваркен', boreal:'Водлозерский', atlantic:'Ватнайёкюдль', pacific:'Монтерей', casia:'Актобе', samerica:'Уюни', british:'Сторновей', vlf:'Эль-Калафате', subter:'Аггтелек' };
  const placeEn = { neurope:'Kvarken', boreal:'Vodlozersky', atlantic:'Vatnajökull', pacific:'Monterey', casia:'Aktobe', samerica:'Uyuni', british:'Stornoway', vlf:'El Calafate', subter:'Aggtelek' };
  const durList = [41, 1448, 2301, 3120, 4350, 6480, 7440, 11648, 2469, 1682, 17298, 8310];

  const generated = [];
  const base = new Date(2025, 10, 28); // anchor on HFR-0395's date
  for (let no = 394; no >= 1; no--) {
    const ti = (no * 7) % titlesRu.length;
    const vi = (no * 3 + 1) % varRu.length;
    const ei = (no * 5) % engRu.length;
    const region = regOrder[(no + 1) % regOrder.length];
    const dur = durList[(no * 11) % durList.length];
    const d = new Date(base.getTime());
    d.setDate(d.getDate() - (395 - no) * 10 - (no % 6));
    const iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const byRu = engRu[ei] + ' · ' + placeRu[region] + ', ' + cc[ei];
    const byEn = engEn[ei] + ' · ' + placeEn[region] + ', ' + cc[ei];
    generated.push(rec(no, iso, dur, region, 'FLAC',
      [titlesRu[ti] + varRu[vi], byRu],
      [titlesEn[ti] + varEn[vi], byEn]));
  }

  window.HINTERLAND_ARCHIVE = seed.concat(generated);
})();
