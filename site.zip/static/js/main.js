/* Hinterland Archive — site scripts (bilingual: RU default, EN fallback) */

(function () {
  const lang = document.documentElement.lang || 'ru';

  const monthsRu = [
    'января','февраля','марта','апреля','мая','июня',
    'июля','августа','сентября','октября','ноября','декабря'
  ];
  const monthsEn = [
    'January','February','March','April','May','June',
    'July','August','September','October','November','December'
  ];

  // Today's date in the topbar
  const today = document.getElementById('today');
  if (today) {
    const d = new Date();
    if (lang === 'ru') {
      today.textContent = `${d.getDate()} ${monthsRu[d.getMonth()]} ${d.getFullYear()}`;
    } else {
      today.textContent = `${d.getDate()} ${monthsEn[d.getMonth()]} ${d.getFullYear()}`;
    }
  }

  // Animated catalogue number drift
  const catNo = document.getElementById('cat-no');
  if (catNo) {
    let base = 418;
    setInterval(() => {
      if (Math.random() < 0.08) {
        base += 1;
        catNo.textContent = 'HFR-' + String(base).padStart(4, '0');
      }
    }, 6000);
  }

  // Last sync timer in footer
  const lastSync = document.getElementById('last-sync');
  if (lastSync) {
    let secs = 0;
    const tpl = lang === 'ru'
      ? { sec: 'с назад', min: 'мин назад', hour: 'ч назад' }
      : { sec: 's ago',  min: 'min ago',   hour: 'h ago' };
    setInterval(() => {
      secs++;
      if (secs < 60) lastSync.textContent = `${secs} ${tpl.sec}`;
      else if (secs < 3600) lastSync.textContent = `${Math.floor(secs/60)} ${tpl.min}`;
      else lastSync.textContent = `${Math.floor(secs/3600)} ${tpl.hour}`;
    }, 1000);
  }

  // Listener counter random walk
  const listeners = document.getElementById('listeners');
  if (listeners) {
    let n = 418;
    setInterval(() => {
      n += Math.floor(Math.random() * 7) - 3;
      if (n < 320) n = 320;
      if (n > 540) n = 540;
      listeners.textContent = n;
    }, 4000);
  }

  // On mobile the nav is a horizontal scroller — bring the active link into view.
  const activeNav = document.querySelector('.nav a.active');
  if (activeNav && activeNav.scrollIntoView) {
    try { activeNav.scrollIntoView({ inline: 'center', block: 'nearest' }); } catch (e) {}
  }

  // Back-to-top button (injected on every page).
  const toTop = document.createElement('button');
  toTop.type = 'button';
  toTop.className = 'to-top';
  toTop.setAttribute('aria-label', lang === 'ru' ? 'Наверх' : 'Back to top');
  toTop.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
  toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  document.body.appendChild(toTop);
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      toTop.classList.toggle('show', window.scrollY > 600);
      ticking = false;
    });
  }, { passive: true });
})();
