/* Hinterland Archive — live radio player (bilingual, HTTPS edition)
 *
 * Drives a real, working internet-radio player from the curated station
 * network in stations.js. On top of basic playback it adds:
 *   • favourites (★) persisted in localStorage, surfaced as a top group;
 *   • a sleep timer that fades the stream out after N minutes;
 *   • a live station search/filter;
 *   • live "now playing" track metadata for streams that expose an API
 *     (Radio Paradise), polled defensively — failure is silent;
 *   • the Media Session API, so lock-screen / notification controls work
 *     on phones.
 *
 * No Web Audio / crossOrigin is used (the waveform is decorative), which
 * keeps playback working against streams that do not send CORS headers.
 * UI strings adapt to <html lang>.
 */

(function () {
  const playBtn = document.getElementById('playBtn');
  if (!playBtn) return;

  const statusEl  = document.getElementById('status');
  const bitrateEl = document.getElementById('bitrate');
  const npTitle   = document.getElementById('np-title');
  const npMeta    = document.getElementById('np-meta');
  const npNow     = document.getElementById('np-now');
  const volSlide  = document.getElementById('vol');
  const wf        = document.getElementById('waveform');
  const network   = document.getElementById('station-network');
  const topLive   = document.getElementById('topbar-live');
  const favBtn    = document.getElementById('favBtn');
  const sleepSel  = document.getElementById('sleepTimer');
  const sleepPill = document.getElementById('sleepPill');
  const searchInp = document.getElementById('stationSearch');
  const lang      = (document.documentElement.lang || 'ru').slice(0, 2);

  const T = lang === 'ru' ? {
    play_aria: 'Включить эфир', pause_aria: 'Поставить на паузу', loading_aria: 'Загрузка',
    pick: 'Выберите станцию и нажмите Play', buffering: 'Буферизация…', streaming: 'В эфире',
    paused: 'На паузе', reconnecting: 'Переподключение…', unreachable: 'Станция недоступна',
    pick_another: 'попробуйте другую станцию', onair: 'В эфире — ',
    favs: 'Избранное', fav_add: 'В избранное', fav_remove: 'Убрать из избранного',
    fav_hint: 'Ваши сохранённые станции — хранятся локально в этом браузере.',
    sleep_off: 'Таймер сна', sleep_left: 'осталось', sleep_done: 'Эфир остановлен таймером сна',
    no_match: 'Ничего не найдено. Очистите поиск.', credits: 'Потоки взяты напрямую с публичных эндпоинтов вещателей: ',
    now: 'Сейчас играет'
  } : {
    play_aria: 'Play stream', pause_aria: 'Pause stream', loading_aria: 'Loading',
    pick: 'Pick a station and press play', buffering: 'Buffering…', streaming: 'On air',
    paused: 'Paused', reconnecting: 'Reconnecting…', unreachable: 'Station unavailable',
    pick_another: 'try another station', onair: 'On air — ',
    favs: 'Favourites', fav_add: 'Add to favourites', fav_remove: 'Remove from favourites',
    fav_hint: 'Your saved stations — kept locally in this browser.',
    sleep_off: 'Sleep timer', sleep_left: 'left', sleep_done: 'Stopped by sleep timer',
    no_match: 'Nothing matches. Clear the search.', credits: 'Streams taken directly from the broadcasters’ public endpoints: ',
    now: 'Now playing'
  };

  const GROUPS = window.HINTERLAND_STATIONS || [];
  const SOURCES = window.HINTERLAND_SOURCES || {};

  // Flatten all stations into one indexable list, tagging each with its group.
  const flat = [];
  GROUPS.forEach(g => {
    (g.stations || []).forEach((s, i) => {
      flat.push(Object.assign({ key: g.id + ':' + i, group: g }, s));
    });
  });

  /* ---- favourites (localStorage) ---- */
  let favs = [];
  try { favs = JSON.parse(localStorage.getItem('hl_favs') || '[]') || []; } catch (e) { favs = []; }
  function isFav(key) { return favs.indexOf(key) !== -1; }
  function saveFavs() { try { localStorage.setItem('hl_favs', JSON.stringify(favs)); } catch (e) {} }
  function toggleFav(key) {
    const i = favs.indexOf(key);
    if (i === -1) favs.push(key); else favs.splice(i, 1);
    saveFavs();
    syncFav(key);
    renderFavs();
  }

  let audio = null;
  let current = null;       // currently selected flat station
  let playing = false;
  let wfTimer = null;
  let npTimer = null;       // now-playing poll
  let npAbort = null;
  let sleepDeadline = 0;
  let sleepTick = null;

  /* ---- waveform (decorative) ---- */
  if (wf && !wf.children.length) {
    for (let i = 0; i < 96; i++) {
      const b = document.createElement('div');
      b.className = 'bar';
      b.style.height = (8 + Math.random() * 8) + 'px';
      wf.appendChild(b);
    }
  }
  function animateWaveform(on) {
    if (!wf) return;
    if (on) {
      wf.classList.add('playing');
      if (!wfTimer) wfTimer = setInterval(() => {
        Array.from(wf.children).forEach(b => { b.style.height = (6 + Math.random() * 68) + 'px'; });
      }, 110);
    } else {
      wf.classList.remove('playing');
      clearInterval(wfTimer); wfTimer = null;
      Array.from(wf.children).forEach(b => { b.style.height = (8 + Math.random() * 8) + 'px'; });
    }
  }

  /* ---- play button icon ---- */
  function setIcon(state) {
    if (state === 'pause') {
      playBtn.innerHTML = '<svg viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
      playBtn.setAttribute('aria-label', T.pause_aria);
    } else if (state === 'loading') {
      playBtn.innerHTML = '<svg viewBox="0 0 24 24" style="animation: spin 1s linear infinite;"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="2" stroke-dasharray="20 30"/></svg>';
      playBtn.setAttribute('aria-label', T.loading_aria);
    } else {
      playBtn.innerHTML = '<svg viewBox="0 0 24 24"><polygon points="6,4 20,12 6,20"/></svg>';
      playBtn.setAttribute('aria-label', T.play_aria);
    }
  }
  const sty = document.createElement('style');
  sty.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
  document.head.appendChild(sty);

  /* ---- station directory ---- */
  function metaLine(s) {
    return [s.fmt, s.place && s.place !== '—' ? s.place : null].filter(Boolean).join(' · ');
  }

  function makeStationButton(s, key) {
    const li = document.createElement('li');
    li.dataset.key = key;
    li.dataset.search = (s.name + ' ' + (s.place || '') + ' ' + (s.fmt || '') + ' ' + s.group.ru + ' ' + s.group.en).toLowerCase();

    const btn = document.createElement('button');
    btn.className = 'station';
    btn.type = 'button';
    btn.dataset.key = key;
    btn.innerHTML =
      '<span class="st-eq" aria-hidden="true"><i></i><i></i><i></i><i></i></span>' +
      '<span class="st-body"><span class="st-name"></span><span class="st-meta"></span></span>';
    btn.querySelector('.st-name').textContent = s.name;
    btn.querySelector('.st-meta').textContent = metaLine(s);
    btn.addEventListener('click', () => select(key, true));

    const star = document.createElement('button');
    star.className = 'st-fav';
    star.type = 'button';
    star.dataset.key = key;
    star.setAttribute('aria-pressed', isFav(key) ? 'true' : 'false');
    star.setAttribute('aria-label', isFav(key) ? T.fav_remove : T.fav_add);
    star.title = isFav(key) ? T.fav_remove : T.fav_add;
    star.textContent = isFav(key) ? '★' : '☆';
    star.addEventListener('click', (e) => { e.stopPropagation(); toggleFav(key); });

    li.appendChild(btn);
    li.appendChild(star);
    return li;
  }

  let favSection = null;

  function renderFavs() {
    if (!network) return;
    if (!favSection) {
      favSection = document.createElement('div');
      favSection.className = 'netgroup';
      favSection.id = 'fav-group';
      network.insertBefore(favSection, network.firstChild);
    }
    if (!favs.length) { favSection.style.display = 'none'; favSection.innerHTML = ''; return; }
    favSection.style.display = '';
    favSection.innerHTML =
      '<div class="netgroup-head"><h3>★ ' + T.favs + '</h3><p class="netgroup-hint">' + T.fav_hint + '</p></div>';
    const ul = document.createElement('ul');
    ul.className = 'station-list';
    favs.forEach(key => {
      const s = flat.find(x => x.key === key);
      if (s) ul.appendChild(makeStationButton(s, key));
    });
    favSection.appendChild(ul);
    if (current) markState(current.key, playing ? 'playing' : 'paused');
    applySearch();
  }

  function renderNetwork() {
    if (!network) return;
    const frag = document.createDocumentFragment();

    GROUPS.forEach(g => {
      const sec = document.createElement('div');
      sec.className = 'netgroup';
      sec.dataset.group = g.id;

      const head = document.createElement('div');
      head.className = 'netgroup-head';
      const h = document.createElement('h3');
      h.textContent = lang === 'ru' ? g.ru : g.en;
      const hint = document.createElement('p');
      hint.className = 'netgroup-hint';
      hint.textContent = lang === 'ru' ? g.hintRu : g.hintEn;
      head.appendChild(h); head.appendChild(hint);
      sec.appendChild(head);

      const ul = document.createElement('ul');
      ul.className = 'station-list';
      (g.stations || []).forEach((s, i) => {
        ul.appendChild(makeStationButton(Object.assign({ group: g }, s), g.id + ':' + i));
      });
      sec.appendChild(ul);
      frag.appendChild(sec);
    });

    network.innerHTML = '';
    network.appendChild(frag);

    // empty-state line for search
    const empty = document.createElement('p');
    empty.className = 'net-empty';
    empty.id = 'net-empty';
    network.appendChild(empty);

    // Source credits
    const credits = document.createElement('div');
    credits.className = 'net-credits';
    const intro = document.createElement('span');
    intro.textContent = T.credits;
    credits.appendChild(intro);
    Object.keys(SOURCES).forEach((k, idx, arr) => {
      const a = document.createElement('a');
      a.href = SOURCES[k].url; a.target = '_blank'; a.rel = 'noopener';
      a.textContent = SOURCES[k].label;
      credits.appendChild(a);
      if (idx < arr.length - 1) credits.appendChild(document.createTextNode(' · '));
    });
    network.appendChild(credits);

    renderFavs();
  }

  function markState(key, state) {
    if (!network) return;
    network.querySelectorAll('.station').forEach(b => {
      const on = b.dataset.key === key;
      b.classList.toggle('active', on);
      b.classList.toggle('playing', on && state === 'playing');
      b.classList.toggle('loading', on && state === 'loading');
      b.classList.toggle('error', on && state === 'error');
      if (!on) b.classList.remove('playing', 'loading', 'error');
    });
  }

  function syncFav(key) {
    if (!network) return;
    network.querySelectorAll('.st-fav[data-key="' + cssKey(key) + '"]').forEach(st => {
      const on = isFav(key);
      st.setAttribute('aria-pressed', on ? 'true' : 'false');
      st.setAttribute('aria-label', on ? T.fav_remove : T.fav_add);
      st.title = on ? T.fav_remove : T.fav_add;
      st.textContent = on ? '★' : '☆';
    });
    if (current && current.key === key) updateFavBtn();
  }
  function cssKey(key) { return (window.CSS && CSS.escape) ? CSS.escape(key) : key; }

  function updateFavBtn() {
    if (!favBtn) return;
    const on = current && isFav(current.key);
    favBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
    favBtn.disabled = !current;
    favBtn.querySelector('.star').textContent = on ? '★' : '☆';
    favBtn.querySelector('.label').textContent = on ? T.fav_remove : T.fav_add;
  }

  /* ---- search ---- */
  function applySearch() {
    if (!network) return;
    const q = (searchInp ? searchInp.value : '').trim().toLowerCase();
    let anyVisible = false;
    network.querySelectorAll('.netgroup').forEach(sec => {
      if (sec.style.display === 'none') return; // hidden favourites group when empty
      let groupVisible = false;
      sec.querySelectorAll('.station-list > li').forEach(li => {
        const match = !q || (li.dataset.search || '').indexOf(q) !== -1;
        li.classList.toggle('is-hidden', !match);
        if (match) groupVisible = true;
      });
      sec.classList.toggle('is-hidden', !groupVisible);
      if (groupVisible) anyVisible = true;
    });
    const empty = document.getElementById('net-empty');
    if (empty) empty.textContent = (q && !anyVisible) ? T.no_match : '';
  }

  /* ---- now playing ---- */
  function showNowPlaying(s) {
    if (npTitle) npTitle.textContent = s.name;
    if (npMeta) {
      const groupName = lang === 'ru' ? s.group.ru : s.group.en;
      npMeta.textContent = [groupName, s.place && s.place !== '—' ? s.place : null].filter(Boolean).join(' · ');
    }
    if (bitrateEl) bitrateEl.textContent = s.fmt || '—';
    if (topLive) topLive.textContent = T.onair + s.name;
    if (npNow) npNow.innerHTML = '';
    updateMediaSession(s, null);
  }

  function stopNowPlaying() {
    if (npTimer) { clearTimeout(npTimer); npTimer = null; }
    if (npAbort) { try { npAbort.abort(); } catch (e) {} npAbort = null; }
    if (npNow) npNow.innerHTML = '';
  }

  function startNowPlaying(s) {
    stopNowPlaying();
    if (!s.np || s.np.p !== 'rp' || typeof fetch !== 'function') return;
    const poll = () => {
      if (npAbort) { try { npAbort.abort(); } catch (e) {} }
      npAbort = ('AbortController' in window) ? new AbortController() : null;
      const opts = npAbort ? { signal: npAbort.signal } : {};
      fetch('https://api.radioparadise.com/api/now_playing?chan=' + s.np.chan, opts)
        .then(r => r.ok ? r.json() : null)
        .then(d => {
          if (!d || current !== s) return;
          let artist = d.artist, title = d.title;
          if ((!artist || !title) && d.song && d.song[0]) { artist = d.song[0].artist; title = d.song[0].title; }
          if (artist || title) {
            const line = [artist, title].filter(Boolean).join(' — ');
            if (npNow) npNow.innerHTML = '<span class="np-spark">♪</span> ' + escapeHtml(line);
            updateMediaSession(s, { artist: artist, title: title, cover: d.cover_med || d.cover || d.cover_small });
          }
          // RP returns seconds left in the current track — refresh just after it ends.
          if (current === s) {
            const wait = (typeof d.time === 'number' && d.time > 0) ? Math.min(d.time + 2, 300) : 30;
            npTimer = setTimeout(poll, wait * 1000);
          }
        })
        .catch(() => { if (current === s) npTimer = setTimeout(poll, 45000); });
    };
    poll();
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }

  /* ---- Media Session (lock-screen controls on phones) ---- */
  function updateMediaSession(s, track) {
    if (!('mediaSession' in navigator)) return;
    try {
      const art = (track && track.cover)
        ? [{ src: track.cover, sizes: '500x500', type: 'image/jpeg' }]
        : [{ src: '/favicon.svg', sizes: '512x512', type: 'image/svg+xml' }];
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track && track.title ? track.title : s.name,
        artist: track && track.artist ? track.artist : (lang === 'ru' ? s.group.ru : s.group.en),
        album: track && track.title ? s.name : ('Hinterland · ' + (lang === 'ru' ? 'Прямой эфир' : 'Live')),
        artwork: art
      });
    } catch (e) {}
  }
  function wireMediaSession() {
    if (!('mediaSession' in navigator)) return;
    try {
      navigator.mediaSession.setActionHandler('play', () => start());
      navigator.mediaSession.setActionHandler('pause', () => { if (audio) audio.pause(); });
      navigator.mediaSession.setActionHandler('stop', () => { if (audio) audio.pause(); });
      navigator.mediaSession.setActionHandler('previoustrack', () => step(-1));
      navigator.mediaSession.setActionHandler('nexttrack', () => step(1));
    } catch (e) {}
  }
  function step(dir) {
    if (!flat.length) return;
    const idx = current ? flat.findIndex(x => x.key === current.key) : -1;
    const next = flat[(idx + dir + flat.length) % flat.length];
    if (next) select(next.key, true);
  }

  /* ---- audio control ---- */
  function buildAudio() {
    const a = new Audio();
    a.preload = 'none';
    a.volume = (volSlide ? volSlide.value : 70) / 100;
    a.addEventListener('playing', () => {
      playing = true;
      if (statusEl) statusEl.textContent = T.streaming;
      setIcon('pause');
      animateWaveform(true);
      if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'playing';
      if (current) { markState(current.key, 'playing'); startNowPlaying(current); }
    });
    a.addEventListener('waiting', () => { if (statusEl) statusEl.textContent = T.buffering; });
    a.addEventListener('pause', () => {
      playing = false;
      if (statusEl) statusEl.textContent = T.paused;
      setIcon('play');
      animateWaveform(false);
      stopNowPlaying();
      if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused';
      if (current) markState(current.key, 'paused');
    });
    a.addEventListener('stalled', () => { if (statusEl) statusEl.textContent = T.reconnecting; });
    a.addEventListener('error', onStreamError);
    return a;
  }

  function onStreamError() {
    playing = false;
    animateWaveform(false);
    setIcon('play');
    stopNowPlaying();
    if (statusEl) statusEl.textContent = T.unreachable;
    if (bitrateEl) bitrateEl.textContent = T.pick_another;
    if (current) markState(current.key, 'error');
  }

  function select(key, autoplay) {
    const s = flat.find(x => x.key === key);
    if (!s) return;
    current = s;
    showNowPlaying(s);
    updateFavBtn();
    markState(key, autoplay ? 'loading' : 'paused');
    if (statusEl) statusEl.textContent = autoplay ? T.buffering : T.pick;
    try { localStorage.setItem('hl_station', key); } catch (e) {}
    if (autoplay) start();
  }

  function start() {
    if (!current) { if (flat.length) select(flat[0].key, true); return; }
    if (!audio) audio = buildAudio();
    setIcon('loading');
    if (statusEl) statusEl.textContent = T.buffering;
    markState(current.key, 'loading');
    try { audio.pause(); } catch (e) {}
    audio.src = current.url;
    audio.load();
    const p = audio.play();
    if (p && p.catch) p.catch(onStreamError);
  }

  function toggle() {
    if (playing && audio && !audio.paused) audio.pause();
    else start();
  }

  /* ---- sleep timer ---- */
  function clearSleep() {
    sleepDeadline = 0;
    if (sleepTick) { clearInterval(sleepTick); sleepTick = null; }
    if (sleepPill) sleepPill.textContent = '';
  }
  function setSleep(mins) {
    clearSleep();
    if (!mins) return;
    sleepDeadline = Date.now() + mins * 60000;
    const tick = () => {
      const left = sleepDeadline - Date.now();
      if (left <= 0) {
        clearSleep();
        if (sleepSel) sleepSel.value = '0';
        if (audio) audio.pause();
        if (statusEl) statusEl.textContent = T.sleep_done;
        return;
      }
      if (sleepPill) {
        const m = Math.floor(left / 60000), sec = Math.floor((left % 60000) / 1000);
        sleepPill.textContent = '⏲ ' + m + ':' + String(sec).padStart(2, '0') + ' ' + T.sleep_left;
      }
    };
    tick();
    sleepTick = setInterval(tick, 1000);
  }

  /* ---- wire up ---- */
  playBtn.addEventListener('click', toggle);

  if (favBtn) favBtn.addEventListener('click', () => { if (current) toggleFav(current.key); });
  if (sleepSel) sleepSel.addEventListener('change', () => setSleep(parseInt(sleepSel.value, 10) || 0));
  if (searchInp) searchInp.addEventListener('input', applySearch);

  if (volSlide) {
    volSlide.addEventListener('input', () => {
      if (audio) audio.volume = volSlide.value / 100;
      try { localStorage.setItem('hl_volume', volSlide.value); } catch (e) {}
    });
    try { const v = localStorage.getItem('hl_volume'); if (v !== null) volSlide.value = v; } catch (e) {}
  }

  // Global keyboard shortcuts. Space toggles play (but not while a control is
  // focused — there the browser's native activation handles it); Alt+← / Alt+→
  // step between stations.
  document.addEventListener('keydown', e => {
    const tag = e.target && e.target.tagName;
    if (e.code === 'Space') {
      if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' || tag === 'BUTTON' || tag === 'A') return;
      e.preventDefault(); toggle();
    } else if (e.altKey && e.code === 'ArrowRight') { e.preventDefault(); step(1); }
    else if (e.altKey && e.code === 'ArrowLeft') { e.preventDefault(); step(-1); }
  });

  renderNetwork();
  wireMediaSession();

  // Restore last station (without autoplay) or default to the first one.
  let restored = null;
  try { restored = localStorage.getItem('hl_station'); } catch (e) {}
  if (restored && flat.some(s => s.key === restored)) select(restored, false);
  else if (flat.length) select(flat[0].key, false);
  setIcon('play');
  updateFavBtn();
  if (statusEl && !current) statusEl.textContent = T.pick;
})();
